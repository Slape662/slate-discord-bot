module.exports = function (prefix, botmsg, client) {
// things to allow the bot to run
const mainFile = require("/home/container/main.js");
client.on("message", function(message) {
  if (botmsg === true) {
    // do nothing
  } else {
    if (message.author.bot) return;
  }
  if (!message.content.startsWith(prefix)) return;

  const commandBody = message.content.slice(prefix.length);
  const args = commandBody.split(' ');
  const command = args.shift().toLowerCase();
  
  if (command === "help") {
    var fullcmd = "";
    var cmds = [
    /*1*/"ping",
    /*2*/"botmsg"];
    
    var desc = [
    /*1*/"Gives you the latency between you and the server.",
    /*2*/"Allows bots to use SlateBot's commands."];

    for (var a = 0; a < cmds.length; a++) {
      fullcmd += prefix + cmds[a] + "》" + desc[a] + "\n";
    }
    message.reply({embed: {
      color: 3447003,
      author: {
        name: "SlateBot》Help",
        icon_url: client.user.avatarURL
      },
      title: "Commands",
      url: "http://slate.dirando.com/apps/bots/commands/",
      description: fullcmd,
      fields: [
      {
        name: "Found an error?",
        value: "Please report any errors in our [Discord Server](https://discord.gg/a5mNMV)!"
      },
      {
        name: "Want to suggest an edit?",
        value: "Suggestions are always wanted. Please suggest in our [Discord Server](https://discord.gg/a5mNMV)."
      },
      {
        name: "About SlateBot",
        value: "Version》0.0.1 Beta"
      }
    ],
    timestamp: new Date(),
    footer: {
      icon_url: client.user.avatarURL,
      text: "SlateBot》Bugs may occur"
    }
  }
});
  } else if (command === "ping") {
    const timeTaken = Date.now() - message.createdTimestamp;
    message.channel.send(`:ping_pong: **${timeTaken}**ms.`);
  }

  else if (command === "sum") {
    const numArgs = args.map(x => parseFloat(x));
    const sum = numArgs.reduce((counter, x) => counter += x);
    message.channel.send(`The sum of all the arguments you provided is ${sum}!`);
  }
  
  else if (command === "prefix") {
    if (message.member.hasPermission(['MANAGE_ROLES'])) {
      const newPrefix = args;
      prefix = newPrefix;
      message.channel.send(`The new prefix for the server is "${prefix}".`);
    } else {
      message.channel.send(`I am sorry, you do not have permission to change the prefix.`);
    }
  } else if (command === "botmsg")  {
    if (message.member.hasPermission(['MANAGE_SERVER'])) {
      if (botmsg == true) {
        botmsg = false;
        var send = require("../../settings.js")(botmsg);
        message.channel.send(`You have changed the setting botmsg to false.`);
      } else {
        botmsg = true;
        var send = require("../../settings.js")(botmsg);
        message.channel.send(`You have changed the setting botmsg to true.`);
      }
    } else {
      message.channel.send(`I am sorry, you do not have permission to change the to change this setting.`);
    }
  } else if (command === "invite") {
    message.reply({embed: {
      color: 3447003,
      author: {
        name: "SlateBot》Invite",
        icon_url: client.user.avatarURL
      },
      title: "Invite",
      url: "http://slate.dirando.com/apps/bots/",
      description: "Invite the bot [here](https://discord.com/oauth2/authorize?client_id=740729946867236886&scope=bot)",
      fields: [
      {
        name: "Found an error?",
        value: "Please report any errors in our [Discord Server](https://discord.gg/a5mNMV)!"
      },
      {
        name: "Want to suggest an edit?",
        value: "Suggestions are always wanted. Please suggest in our [Discord Server](https://discord.gg/a5mNMV)."
      },
      {
        name: "About SlateBot",
        value: "Version》0.0.1 Beta"
      }
    ],
    timestamp: new Date(),
    footer: {
      icon_url: client.user.avatarURL,
      text: "SlateBot》Bugs may occur"
    }
  }
});
  } else {
    //do nothing
  }
});
}