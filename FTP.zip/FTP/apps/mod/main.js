module.exports = function (prefix, settings, client) {
  // things to allow the bot to run
  const mainFile = require("/home/container/main.js");
  client.on("message", function (message) {
    if (botmsg === true) {
      // do nothing
    } else {
      if (message.author.bot) return;
    }
    if (!message.content.startsWith(prefix)) return;
    const commandBody = message.content.slice(prefix.length);
    const args = commandBody.split(' ');
    const command = args.shift().toLowerCase();

    if (command === "ban") {
        args.roles.set(['Banned'])
        .then(console.log)
        .catch(console.error);
    } else if (command === "unban") {
      args.roles.remove("Banned");
    }
  });
}
